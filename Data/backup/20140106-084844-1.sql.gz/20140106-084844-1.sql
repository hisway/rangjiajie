-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 
-- Database : rangjiajie
-- 
-- Part : #1
-- Date : 2014-01-06 08:48:44
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `ws_admin`
-- -----------------------------
DROP TABLE IF EXISTS `ws_admin`;
CREATE TABLE `ws_admin` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `last_login` int(11) NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL DEFAULT '',
  `action_list` text NOT NULL,
  `role_id` smallint(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_name` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ws_admin`
-- -----------------------------
INSERT INTO `ws_admin` VALUES ('1', 'admin', '', '.', '0', '1388968885', '127.0.0.1', '', '0');

-- -----------------------------
-- Table structure for `ws_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `ws_auth_group`;
CREATE TABLE `ws_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` char(80) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `ws_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `ws_auth_group_access`;
CREATE TABLE `ws_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `ws_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `ws_auth_rule`;
CREATE TABLE `ws_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `condition` char(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `ws_brand`
-- -----------------------------
DROP TABLE IF EXISTS `ws_brand`;
CREATE TABLE `ws_brand` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(90) NOT NULL DEFAULT '',
  `brand_desc` varchar(255) NOT NULL DEFAULT '',
  `cat_id` varchar(100) NOT NULL,
  `sort_order` tinyint(1) unsigned NOT NULL DEFAULT '50',
  `show_in_nav` tinyint(1) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ws_brand`
-- -----------------------------
INSERT INTO `ws_brand` VALUES ('14', 'TCL', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('15', 'Hisense/海信', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('17', 'Skyworth/创维', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('18', 'KONKA/康佳', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('40', 'Toshiba/东芝', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('39', 'Haier/海尔', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('21', 'Panasonic/松下', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('22', 'SHARP/夏普', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('25', 'Philips/飞利浦', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('26', '乐视TV', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('27', 'SANYO/三洋', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('28', 'SAMSUNG/三星', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('29', 'LG', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('30', 'Toshiba/东芝', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('31', 'Changhong/长虹', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('32', 'Haier/海尔', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('33', 'coocaa/酷开', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('34', 'PRIMA/厦华', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('35', 'SIEMENS/西门子', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('36', 'AOC', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('37', 'Lenovo/联想', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('41', 'Ponasonic/松下', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('42', 'SHARP/夏普', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('43', 'KELON/科龙', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('44', 'AUX/奥克斯', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('45', 'LG', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('46', 'Midea/美的', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('47', 'Ronshen/容声', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('48', 'SIEMENS/西门子', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('49', 'Hisense/海信', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('50', 'TCL', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('51', 'Galanz/格兰仕', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('52', '星星', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('53', 'Homa/奥马', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('54', 'FRESTECH/新飞', '', '121112', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('61', 'Sony/索尼', '', '121111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('59', '星星', '', '121113', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('60', 'TCL', '', '121115', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('62', '滚石', '', '111111', '50', '0', '1');
INSERT INTO `ws_brand` VALUES ('63', '环球', '', '111111', '50', '0', '1');

-- -----------------------------
-- Table structure for `ws_cate`
-- -----------------------------
DROP TABLE IF EXISTS `ws_cate`;
CREATE TABLE `ws_cate` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(500) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `cat_desc` varchar(255) NOT NULL DEFAULT '',
  `cat_id` varchar(100) NOT NULL COMMENT 'cat_id',
  `sort_order` tinyint(1) unsigned NOT NULL DEFAULT '50',
  `template_file` varchar(50) NOT NULL DEFAULT '',
  `unit` varchar(15) NOT NULL DEFAULT '0',
  `show_in_nav` tinyint(1) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cat_id` (`cat_id`),
  KEY `sort_order` (`sort_order`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ws_cate`
-- -----------------------------
INSERT INTO `ws_cate` VALUES ('14', '图书音像', '', '', '11', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('15', '图书音像/音像', '', '', '1111', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('20', '图书音像/音像/音乐', '', '', '111111', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('21', '图书音像/音像/影视', '', '', '111112', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('22', '图书音像/音像/教育', '', '', '111113', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('23', '图书音像/音像/游戏', '', '', '111114', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('24', '图书音像/音像/其他', '', '', '111115', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('25', '图书音像/音像/音乐/古典音乐', '', '', '11111111', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('26', '图书音像/音像/音乐/通俗流行', '', '', '11111112', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('29', '图书音像/音像/音乐/摇滚说唱', '', '', '11111113', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('30', '图书音像/音像/音乐/乡村民谣', '', '', '11111114', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('31', '图书音像/音像/音乐/爵士蓝调', '', '', '11111115', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('35', '图书音像/文艺/小说', '', '', '111211', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('34', '图书音像/文艺', '', '', '1112', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('36', '图书音像/文艺/文学', '', '', '111212', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('37', '图书音像/文艺/传记', '', '', '111213', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('38', '图书音像/文艺/艺术', '', '', '111214', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('39', '图书音像/文艺/小说/侦探推理', '', '', '11121111', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('40', '图书音像/文艺/小说/玄幻奇幻', '', '', '11121112', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('41', '图书音像/文艺/小说/恐怖惊悚', '', '', '11121113', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('42', '图书音像/文艺/小说/爱情小说', '', '', '11121114', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('43', '图书音像/文艺/小说/青春小说', '', '', '11121115', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('44', '图书音像/文艺/小说/武侠小说', '', '', '11121116', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('45', '图书音像/文艺/小说/职场小说', '', '', '11121117', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('46', '图书音像/文艺/小说/网络小说', '', '', '11121118', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('47', '图书音像/文艺/小说/军旅小说', '', '', '11121119', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('48', '图书音像/文艺/小说/中国古典小说', '', '', '11121120', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('49', '图书音像/音像/影视/电影', '', '', '11111211', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('50', '图书音像/音像/影视/电视剧', '', '', '11111212', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('51', '图书音像/音像/影视/卡通动画', '', '', '11111213', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('52', '图书音像/音像/影视/儿童影视', '', '', '11111214', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('53', '图书音像/音像/影视/综艺戏剧', '', '', '11111215', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('55', '图书音像/音像/影视/纪录片', '', '', '11111216', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('56', '图书音像/音像/影视/其他', '', '', '11111217', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('57', '图书音像/音像/教育视频/儿童教育', '', '', '11111311', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('58', '图书音像/音像/教育视频/英语学习', '', '', '11111312', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('59', '图书音像/音像/教育视频/汉语、小语种', '', '', '11111313', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('60', '图书音像/音像/教育视频/教学辅导', '', '', '11111314', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('61', '图书音像/音像/教育视频/考试', '', '', '11111315', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('62', '图书音像/音像/教育视频/职业培训', '', '', '11111316', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('63', '图书音像/音像/教育视频/其他', '', '', '11111317', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('64', '图书音像/音像/游戏/卡牌游戏', '', '', '11111411', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('65', '图书音像/音像/游戏/三国杀', '', '', '11111412', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('66', '图书音像/音像/游戏/角色扮演', '', '', '11111413', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('67', '图书音像/音像/游戏/射击游戏', '', '', '11111414', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('68', '图书音像/音像/游戏/模拟经营', '', '', '11111415', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('69', '图书音像/音像/游戏/恋爱养成', '', '', '11111416', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('70', '图书音像/音像/游戏/体育竞技', '', '', '11111417', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('71', '图书音像/音像/游戏/赛车竞速', '', '', '11111418', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('72', '家电办公', '', '', '12', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('73', '手机数码', '', '', '13', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('74', '家居厨具', '', '', '14', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('75', '服饰鞋帽', '', '', '15', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('76', '个护化妆', '', '', '16', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('77', '礼品箱包', '', '', '17', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('78', '运动户外', '', '', '18', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('79', '母婴玩具', '', '', '19', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('80', '食品饮料', '', '', '20', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('81', '家电办公/大家电', '', '', '1211', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('82', '家电办公/生活电器', '', '', '1212', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('83', '家电办公/个人护理', '', '', '1213', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('84', '家电办公/影音电器', '', '', '1214', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('85', '家电办公/办公文具', '', '', '1215', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('86', '家电办公/厨房电器', '', '', '1216', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('87', '家电办公/文化用品', '', '', '1217', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('88', '家电办公/大家电/平板电视', '', '', '121111', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('89', '家电办公/大家电/冰箱', '', '', '121112', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('90', '家电办公/大家电/冷柜', '', '', '121113', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('91', '家电办公/大家电/空调', '', '', '121114', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('92', '家电办公/大家电/洗衣机', '', '', '121115', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('93', '家电办公/大家电/燃气灶', '', '', '121116', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('94', '家电办公/大家电/油烟机', '', '', '121117', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('95', '家电办公/大家电/消毒柜', '', '', '121118', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('96', '家电办公/大家电/热水器', '', '', '121119', '50', '', '0', '0', '1');
INSERT INTO `ws_cate` VALUES ('97', '家电办公/大家电/家庭影院', '', '', '121120', '50', '', '0', '0', '1');

-- -----------------------------
-- Table structure for `ws_config`
-- -----------------------------
DROP TABLE IF EXISTS `ws_config`;
CREATE TABLE `ws_config` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `code` varchar(30) NOT NULL DEFAULT '',
  `type` varchar(10) NOT NULL DEFAULT '',
  `store_dir` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `sort_order` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `ws_goods`
-- -----------------------------
DROP TABLE IF EXISTS `ws_goods`;
CREATE TABLE `ws_goods` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cat_id` varchar(100) NOT NULL COMMENT '类别id',
  `goods_sn` varchar(60) NOT NULL DEFAULT '' COMMENT '商品索引(二维码)',
  `goods_name` varchar(120) NOT NULL DEFAULT '',
  `click_count` int(10) unsigned NOT NULL DEFAULT '0',
  `brand_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '牌子',
  `goods_number` smallint(5) unsigned NOT NULL DEFAULT '0',
  `goods_weight` decimal(10,3) unsigned NOT NULL DEFAULT '0.000',
  `market_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `shop_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '快递费用',
  `promote_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `promote_start_date` char(100) NOT NULL,
  `promote_end_date` char(100) NOT NULL,
  `keyword_id` varchar(255) NOT NULL DEFAULT '' COMMENT '属性id',
  `goods_brief` varchar(255) NOT NULL DEFAULT '',
  `goods_desc` text NOT NULL,
  `goods_thumb` varchar(255) NOT NULL DEFAULT '',
  `goods_img` varchar(255) NOT NULL DEFAULT '',
  `original_img` varchar(255) NOT NULL DEFAULT '',
  `is_on_sale` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `sort_order` smallint(4) unsigned NOT NULL DEFAULT '100',
  `is_delete` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_best` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_new` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_hot` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_promote` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL,
  `last_update` datetime NOT NULL,
  `is_check` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `goods_sn` (`goods_sn`),
  KEY `cat_id` (`cat_id`),
  KEY `last_update` (`last_update`),
  KEY `brand_id` (`brand_id`),
  KEY `goods_weight` (`goods_weight`),
  KEY `promote_end_date` (`promote_end_date`),
  KEY `promote_start_date` (`promote_start_date`),
  KEY `goods_number` (`goods_number`),
  KEY `sort_order` (`sort_order`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ws_goods`
-- -----------------------------
INSERT INTO `ws_goods` VALUES ('26', '121111', '52c7a83eae10f.png', 'Sony 索尼KDL-50R556A 50英寸全高清智能3D液晶电视（2013年新款）', '0', '61', '0', '0.000', '8799.00', '0.00', '0.00', '', '', '9,10', '', '<p><big style=\"font-family: verdana, arial, helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><strong><span style=\"color: rgb(204, 102, 0);\">详细参数</span></strong></big><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/></p><table bordercolor=\"#E6E6E6\" class=\"data\"><tbody><tr class=\"firstRow\"><td colspan=\"2\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><strong>基本参数</strong></td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">屏幕对角线尺寸</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">50英寸</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">显示屏比率</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">16 :9</td></tr><tr><td colspan=\"2\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><strong>画质</strong></td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">分辨率</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">1920 × 1080</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">背光源</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">LED背光源</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">数字信号处理系统</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">BRAVIA ENGINE 3 图像处理引擎</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">特丽魅彩显示技术</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">-</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">Motionflow 倍速驱动</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">Motionflow XR 200</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">双画面功能</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">单调谐器双画面/画中画*</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">光感器</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">－</td></tr><tr><td colspan=\"2\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><strong>音质</strong></td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">声音结构</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">-</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">扬声器</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">-</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">Surround 三维环绕声系统</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">模拟环绕声</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">语音清晰</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">-</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">智能音量控制</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">-</td></tr><tr><td colspan=\"2\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><strong>智能</strong></td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">一触镜像</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">-</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">屏幕镜像</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">●</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">智能连接</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">●</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">多屏遥控</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">-</td></tr><tr><td colspan=\"2\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><strong>功能</strong></td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">DLNA家庭娱乐网络</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">-</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">BRAVIA Sync 功能</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">●</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">数码相框</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">●</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">无线网络</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">●</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">互联网浏览器</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">●</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">USB媒体播放</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">●</td></tr><tr><td colspan=\"2\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><strong>输入输出</strong></td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">HDMI接口</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">4</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">电脑接口+音频输入<br/>(立体声微型)</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">-</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">USB 接口</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">2</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">数字音频输出<br/>(光纤)</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">●</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">立体声微型耳机输出端子</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">●(与音频输出端子公用)</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">网线接口<br/>(LAN)</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">●</td></tr><tr><td colspan=\"2\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><strong>其他</strong></td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">显示单元尺寸<br/>(宽x高x深)厘米&nbsp;<br/>带底座</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">约 113.1 厘米 × 70.2 厘米 × 23.3 厘米</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">显示单元尺寸<br/>(宽x高x深)厘米</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">约 113.1 厘米 × 67.1 厘米 × 8.4 厘米</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">可视图像对角线尺寸</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">约 125.7 厘米 (50英寸)</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">显示单元净重 KG 带底座</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">约 18.6 公斤</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">显示单元净重 KG</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">约 17.7 公斤</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">外包装箱尺寸<br/>(宽×高×深) 厘米</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">-</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">外包装箱重量 KG&nbsp;<br/>(包括电视机)</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">-</td></tr><tr><td width=\"192\" style=\"font-size: small; border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">电源要求</td><td width=\"338\" style=\"font-size: small; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\">220V 50Hz<br/><br/></td></tr></tbody></table><p><br/></p>', '', 'images/2013/12/24/52b945fec95a0.jpg', '', '0', '100', '0', '1', '0', '0', '0', '2013-12-24 16:29:50', '0000-00-00 00:00:00', '0');
INSERT INTO `ws_goods` VALUES ('25', '121111', '52c6615c9c8d4.png', 'KONKA 康佳 LED47F3530F 47英寸 网络智能 IPS硬屏3DLED液晶电视(黑色)', '0', '18', '0', '0.000', '5399.00', '0.00', '3198.00', '2013', '2014', '3,6', '', '<h2 style=\"color: rgb(204, 102, 0); font-size: medium; margin: 0px 0px 0.25em; font-family: verdana, arial, helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><strong>产品参数</strong></h2><p><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">品牌：康佳（KONKA)&nbsp;</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">型号：LED47F3530F</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">尺寸：47英寸</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">产品类别：液晶电视</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">电力消耗(W):95W</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">工作电压：110V-220V</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">显示比例：16:9</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">分辨率：1920*1080</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">刷新率：120HZ</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">面板类型：IPS硬屏</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">屏幕寿命：100000小时</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">扫描方式：逐行扫描</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">响应时间：3MS</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">背光灯类型：LED发光二极管</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">LED背光源分类：侧入式</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">音频系统：全方位立体环绕声</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">操作系统：OMI系统</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">节能等级：1级能效</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">机身输入接口：天线输入端子*1、AV视频输入*1、YPbPr*1、HDMI*1、立体声输入端子*2、USB*1、，以太网端子*1</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">机身输出接口：视频输出端子*1、耳机*1、USB</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">支持图片格式：JPG，JPEG，PNG，BMPUSB</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">支持视频格式：MP4，3GP，AVI，MPG，RM，RMVB，MOV，MKV，MPEGUSB支持音频格式：支持MP3/WMA/AAC</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">网络连接：支持有限连接和无线连接</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">单屏尺寸（宽*厚*高）：1078*632*92mm</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">含底座重量：16KG</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">含底座尺寸（宽*厚*高）：1078*685*275mm</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">外包装尺寸（宽*厚*高）：1356*776*185mm</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">外包装重量：20.5KG</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/></p><h2 style=\"color: rgb(204, 102, 0); font-size: medium; margin: 0px 0px 0.25em; font-family: verdana, arial, helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><strong>厂商信息</strong></h2><p><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">售后服务热线：4008800016</span></p><p><br/></p>', '', 'images/2013/12/24/52b9455edfb45.jpg', '', '1', '100', '0', '1', '0', '0', '0', '2014-01-04 10:42:11', '0000-00-00 00:00:00', '0');
INSERT INTO `ws_goods` VALUES ('24', '121111', '52c6616e60dbc.png', 'Sony 索尼KLV-32R426A 3222英寸LED电视(内置底座，2013年款型号) ', '0', '61', '0', '0.000', '4999.00', '0.00', '3999.00', '2013', '2013', '3,5', '', '<h2 style=\"color: rgb(204, 102, 0); font-size: medium; margin: 0px 0px 0.25em;\"><strong>产品参数</strong></h2><p><br/></p><table bordercolor=\"#E6E6E6\" class=\"data\"><tbody><tr class=\"firstRow\"><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">产品型号</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">KLV-32R426A</p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">屏幕对角线尺寸</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\"><strong>32</strong><strong>英寸</strong></p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">分辨率</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\"><strong>1366 × 768</strong></p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">背光源</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">LED背光源</p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">数字信号处理系统</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">BRAVIA ENGINE 3 图像处理引擎</p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">Motionflow 倍速驱动</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">Motionflow XR 100</p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">Surround 三维环绕声系统</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">模拟环绕声</p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">语音清晰</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">-</p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">HDMI接口</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">2</p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">电脑接口+音频输入<br/>(立体声微型)</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">1(与HDMI-DVI音频输入共用)</p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">USB 接口</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">1</p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">网线接口<br/>(LAN)</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">-</p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">显示单元尺寸<br/>(宽x高x深)厘米&nbsp;<br/>带底座</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\"><strong>约</strong><strong>&nbsp;73.1&nbsp;</strong><strong>厘米</strong><strong>&nbsp;× 46.6&nbsp;</strong><strong>厘米</strong><strong>&nbsp;× 17.1&nbsp;</strong><strong>厘米</strong></p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">显示单元尺寸<br/>(宽x高x深)厘米</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\"><strong>约</strong><strong>&nbsp;73.1&nbsp;</strong><strong>厘米</strong><strong>&nbsp;× 44.1&nbsp;</strong><strong>厘米</strong><strong>&nbsp;× 7.6&nbsp;</strong><strong>厘米</strong></p></td></tr><tr><td style=\"border-left-width: 0px; border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\">可视图像对角线尺寸</p></td><td style=\"border-left-color: rgb(204, 204, 204); border-bottom-style: dotted; border-bottom-color: rgb(204, 204, 204); padding-top: 3px; padding-bottom: 3px;\"><p style=\"margin-bottom: 1em;\"><strong>约</strong><strong>&nbsp;80.0&nbsp;</strong><strong>厘米</strong><strong>&nbsp;(32</strong><strong>英寸</strong><strong>)</strong></p></td></tr></tbody></table><p><br/><br/></p><h2 style=\"color: rgb(204, 102, 0); font-size: medium; margin: 0px 0px 0.25em;\"><strong>厂商信息</strong></h2><p><br/>售后电话4008109000</p><h3 class=\"productDescriptionSource\" style=\"color: rgb(204, 102, 0); font-size: 12px; font-weight: normal; margin: 0.75em 0px 0.375em -15px; clear: both; font-family: verdana, arial, helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">包装清单</h3><table bordercolor=\"#E6E6E6\" class=\"data\"><tbody><tr class=\"firstRow\"><td>序号</td><td>名称</td><td>数量</td></tr><tr><td>1</td><td>台式底座</td><td>1</td></tr><tr><td>2</td><td>台式底座固定螺丝</td><td>2</td></tr><tr><td>3</td><td>RM-SA024遥控器</td><td>1</td></tr><tr><td>4</td><td>AAA电池</td><td>2</td></tr><tr><td>5</td><td>天线隔离器</td><td>1</td></tr><tr><td>6</td><td>使用说明书</td><td>1</td></tr><tr><td>7</td><td>保修卡</td><td>1</td></tr></tbody></table><p><br/></p>', '', 'images/2013/12/24/52b941ff02060.jpg', '', '0', '100', '0', '0', '0', '0', '1', '2013-12-24 17:55:24', '0000-00-00 00:00:00', '0');
INSERT INTO `ws_goods` VALUES ('27', '121111', '52c6617e05fb9.png', 'PHILIPS 飞利浦 32PFL3045/T3 32英寸高清LED电视(超窄边框/支持USB视频) ', '0', '25', '0', '0.000', '1899.00', '0.00', '1599.00', '2013', '2014', '9,6', '', '<h2 style=\"color: rgb(204, 102, 0); font-size: medium; margin: 0px 0px 0.25em; font-family: verdana, arial, helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">基本信息</h2><ul style=\"list-style-type: none;\" class=\" list-paddingleft-2\"><li><p><strong>商品尺寸:&nbsp;</strong>95.2 x 56.3 x 7.6 cm</p></li><li><p><strong>商品重量:&nbsp;</strong>10 Kg</p></li><li><p><strong>发货重量:</strong>&nbsp;14 Kg</p></li><li><p><strong>ASIN:</strong>&nbsp;B00FGKD8LM</p></li><li><p><strong>型号:</strong>&nbsp;LED42K30JD</p></li><li><p><strong>用户评分:</strong>&nbsp;<span class=\"crAvgStars\"><span class=\"asinReviewsSummary\" name=\"B00FGKD8LM\" ref=\"dp_db_cm_cr_acr_pop_\"><a href=\"http://www.amazon.cn/product-reviews/B00FGKD8LM/ref=dp_db_cm_cr_acr_img?ie=UTF8&showViewpoints=1\" name=\"reviewHistoPop_B00FGKD8LM_8915_star__contentDiv_reviewHistoPop_B00FGKD8LM_8915\" style=\"color: rgb(0, 51, 153); text-decoration: none;\"><span class=\"swSprite s_star_4_5 \" title=\"平均4.6 星\" style=\"display: inline-block; margin: 0px; padding: 0px; position: relative; overflow: hidden; vertical-align: baseline; background-image: url(http://g-ec4.images-amazon.com/images/G/28/common/sprites/sprite-site-wide-2._V146303874_.png); top: 1px; width: 65px; height: 13px; background-position: -30px -20px; background-repeat: no-repeat no-repeat;\"><span style=\"position: absolute; left: -9999px;\">平均4.6 星</span></span>&nbsp;</a>&nbsp;<span class=\"histogramButton\" style=\"margin-left: -3px;\"><a href=\"http://www.amazon.cn/product-reviews/B00FGKD8LM/ref=dp_db_cm_cr_acr_img?ie=UTF8&showViewpoints=1\" name=\"reviewHistoPop_B00FGKD8LM_8915_button__contentDiv_reviewHistoPop_B00FGKD8LM_8915\" style=\"color: rgb(0, 51, 153); text-decoration: none;\"><span class=\"swSprite s_chevron \" style=\"display: inline-block; margin: 0px; padding: 0px; position: relative; overflow: hidden; vertical-align: baseline; background-image: url(http://g-ec4.images-amazon.com/images/G/28/common/sprites/sprite-site-wide-2._V146303874_.png); top: 1px; width: 11px; height: 11px; background-position: -30px -40px; background-repeat: no-repeat no-repeat;\"><span style=\"position: absolute; left: -9999px;\">浏览全部评论</span></span>&nbsp;</a></span></span>(<a href=\"http://www.amazon.cn/product-reviews/B00FGKD8LM/ref=dp_db_cm_cr_acr_txt?ie=UTF8&showViewpoints=1\" style=\"color: rgb(0, 51, 153);\">7 条商品评论</a>)</span></p></li><li><p><strong>亚马逊热销商品排名:</strong>&nbsp;电视 、音响 商品里排第8名 (<a href=\"http://www.amazon.cn/gp/bestsellers/audio-video/ref=pd_dp_ts_av_1\" style=\"color: rgb(0, 51, 153);\">查看 电视 、音响 商品销售排行榜</a>)</p></li><ul class=\"zg_hrsr list-paddingleft-2\" style=\"list-style-type: circle;\"><li><p><span class=\"zg_hrsr_rank\" style=\"display: inline-block; width: 50px; text-align: right;\">第4位</span>&nbsp;<span class=\"zg_hrsr_ladder\">-&nbsp;<a href=\"http://www.amazon.cn/gp/bestsellers/audio-video/ref=pd_zg_hrsr_av_1_1\" style=\"color: rgb(0, 51, 153);\">&nbsp;电视 、音响&nbsp;</a>&gt;&nbsp;<strong><a href=\"http://www.amazon.cn/gp/bestsellers/audio-video/874269051/ref=pd_zg_hrsr_av_1_2_last\" style=\"color: rgb(0, 51, 153);\">平板电视</a></strong></span></p></li></ul></ul><p><br/></p>', '', 'images/2013/12/24/52b9483485b97.jpg', '', '1', '100', '0', '1', '0', '0', '1', '2014-01-04 10:42:11', '0000-00-00 00:00:00', '0');
INSERT INTO `ws_goods` VALUES ('28', '121111', '52c65e830fe84.png', 'SHARP 夏普LCD-60X50A 60英寸3D LED液晶电视', '0', '22', '0', '0.000', '29999.00', '0.00', '15999.00', '2013', '2014', '3,6', '', '<p><big style=\"font-family: verdana, arial, helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><strong><span style=\"color:#cc6600\">包装清单</span></strong></big><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">附件配置: 底座×1, 说明书×1, 遥控器×1, 电池×2, 保修卡×1. 3D眼镜一副</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><big style=\"font-family: verdana, arial, helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><strong><span style=\"color:#CC6600\">详细参数</span></strong></big><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">品牌：夏普&nbsp;</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">型号：LCD-60X50A</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">类别：LED电视</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">尺寸：60英寸&nbsp;</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">能效等级：1级</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">显示比例：16：9&nbsp;</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">分辨率：1920*1080</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">液晶显示屏 ：X超液晶面板</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">数字电视一体机&nbsp;</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">智能光控（OPC）&nbsp;</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">端口 HDMI端口：4&nbsp;</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">视频输入端子：2</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">音频输入端子：3</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">PC输入：1</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">Y,Pb,Pr分量视频输入端子：1</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">音频输出端子：1</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">USB：2</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">LAN（网络） ：1</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">光纤数字音频输出 :：1</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">RS-232端口：1</span><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><big style=\"font-family: verdana, arial, helvetica, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\"><strong><span style=\"color:#CC6600\">使用说明</span></strong></big><br style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; white-space: normal; background-color: rgb(255, 255, 255);\"/><span style=\"font-family: verdana, arial, helvetica, sans-serif; font-size: small; line-height: 19px; background-color: rgb(255, 255, 255);\">收货后请打夏普售后上门安装，切勿自行拆箱。使用前请仔细阅读说明书。供电电源的电压必须与本产品上所述的一致。使用前请仔细阅读说明书。供电电源的电压必须与本产品上所述的一致。</span></p>', '', 'images/2013/12/25/52ba4e62e9a1c.jpg', '', '0', '100', '0', '1', '0', '0', '1', '2013-12-25 11:17:56', '0000-00-00 00:00:00', '0');
INSERT INTO `ws_goods` VALUES ('31', '121112', '52c65632409c4.png', 'knock down III', '0', '40', '0', '0.000', '1999.00', '0.00', '1888.00', '2013', '2013', '14,18', '', '<p>单眼文一条线<br/></p>', '', '2014_01_0311_28_2532.jpg', '', '1', '100', '0', '1', '0', '0', '1', '2014-01-03 14:59:07', '0000-00-00 00:00:00', '0');
INSERT INTO `ws_goods` VALUES ('29', '121111', '52c65ff307d9c.png', 'knock downsss', '0', '14', '0', '0.000', '1999.00', '0.00', '999.00', '2013', '2014', '2,11', '', '<p>你好。</p>', '', '2014_01_0216_36_194ade6c.jpg', '', '0', '100', '0', '0', '0', '0', '1', '2014-01-02 16:36:28', '0000-00-00 00:00:00', '0');
INSERT INTO `ws_goods` VALUES ('30', '121112', '52c65844d582a.png', 'knocks down II', '0', '40', '0', '0.000', '4999.00', '0.00', '2999.00', '2013', '2014', '13,20', '', '<p>beauty</p>', '', '2014_01_0310_46_17b780df.gif', '', '1', '100', '0', '1', '0', '0', '1', '2014-01-03 14:59:08', '0000-00-00 00:00:00', '0');
INSERT INTO `ws_goods` VALUES ('32', '121111', '52c657219f785.png', 'knock down IV', '0', '14', '0', '0.000', '5999.00', '0.00', '4666.00', '2013-12-25', '2014-1-15', '2,6', '', '<p>香港电影。</p>', '', '2014_01_0313_10_1031.jpg', '', '1', '100', '0', '1', '0', '0', '1', '2014-01-03 14:59:07', '0000-00-00 00:00:00', '0');
INSERT INTO `ws_goods` VALUES ('33', '121111', '52c7bedd91411.png', '人性的揭露', '0', '21', '0', '0.000', '1999.00', '0.00', '8888.00', '2013-12-25', '2014-1-15', '2,11', '', '<p>人性的揭露</p>', '', '2014_01_04_15_56_17dd98d0.jpg', '', '1', '100', '0', '1', '0', '0', '1', '2014-01-04 15:57:25', '0000-00-00 00:00:00', '');

-- -----------------------------
-- Table structure for `ws_keyword`
-- -----------------------------
DROP TABLE IF EXISTS `ws_keyword`;
CREATE TABLE `ws_keyword` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cat_id` varchar(100) CHARACTER SET utf8 NOT NULL,
  `pid` int(11) NOT NULL,
  `name` char(50) CHARACTER SET utf8 NOT NULL,
  `path` char(50) NOT NULL,
  `is_show` tinyint(4) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `ws_keyword`
-- -----------------------------
INSERT INTO `ws_keyword` VALUES ('1', '121111', '0', '尺寸', '0', '1', '2013-12-21 04:00:00');
INSERT INTO `ws_keyword` VALUES ('2', '121111', '1', '19寸', '0-1', '1', '2013-12-11 12:00:00');
INSERT INTO `ws_keyword` VALUES ('3', '121111', '1', '28寸', '0-1', '1', '2013-12-14 12:00:00');
INSERT INTO `ws_keyword` VALUES ('4', '121111', '0', '颜色', '0', '1', '2013-12-21 04:00:00');
INSERT INTO `ws_keyword` VALUES ('5', '121111', '1', '白色', '0-4', '1', '2013-12-11 12:00:00');
INSERT INTO `ws_keyword` VALUES ('6', '121111', '1', '黑色', '0-4', '1', '2013-12-11 12:00:00');
INSERT INTO `ws_keyword` VALUES ('9', '121111', '1', '32寸', '0-1', '1', '2013-12-21 05:00:00');
INSERT INTO `ws_keyword` VALUES ('10', '121111', '4', '红色', '0-4', '1', '2013-12-21 11:00:00');
INSERT INTO `ws_keyword` VALUES ('11', '121111', '4', '灰色', '0-4', '1', '2013-12-21 10:11:39');
INSERT INTO `ws_keyword` VALUES ('12', '121112', '0', '箱门', '0', '1', '2013-12-21 14:29:21');
INSERT INTO `ws_keyword` VALUES ('13', '121112', '0', '单门', '0-12', '1', '2013-12-21 14:29:42');
INSERT INTO `ws_keyword` VALUES ('14', '121112', '0', '双门', '0-12', '1', '2013-12-21 14:29:55');
INSERT INTO `ws_keyword` VALUES ('15', '121112', '0', '三门', '0-12', '1', '2013-12-21 14:30:35');
INSERT INTO `ws_keyword` VALUES ('16', '121112', '0', '容积', '0', '1', '2013-12-21 14:30:51');
INSERT INTO `ws_keyword` VALUES ('17', '121112', '0', '100升以下', '0-16', '1', '2013-12-21 14:32:05');
INSERT INTO `ws_keyword` VALUES ('18', '121112', '0', '101-200升', '0-16', '1', '2013-12-21 14:32:24');
INSERT INTO `ws_keyword` VALUES ('19', '121112', '0', '201-300升', '0-16', '1', '2013-12-21 14:32:46');
INSERT INTO `ws_keyword` VALUES ('20', '121112', '0', '300升以上', '0-16', '1', '2013-12-24 13:59:02');

-- -----------------------------
-- Table structure for `ws_message`
-- -----------------------------
DROP TABLE IF EXISTS `ws_message`;
CREATE TABLE `ws_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text CHARACTER SET utf8 NOT NULL,
  `is_show` tinyint(4) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `ws_message`
-- -----------------------------
INSERT INTO `ws_message` VALUES ('1', '24', '2', '制冷效果不错，容量也足，值得购买。', '1', '2013-12-24 14:35:29');
INSERT INTO `ws_message` VALUES ('2', '27', '2', '制冷效果不好，容量跟说明有差，不推荐购买。', '0', '2013-12-24 14:35:29');
INSERT INTO `ws_message` VALUES ('3', '30', '2', '色彩不好，有躁点，唯一的优点就是便宜，不推荐购买。', '0', '2013-12-24 14:35:29');

-- -----------------------------
-- Table structure for `ws_order`
-- -----------------------------
DROP TABLE IF EXISTS `ws_order`;
CREATE TABLE `ws_order` (
  `order_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(20) NOT NULL DEFAULT '',
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `order_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `shipping_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pay_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `country` smallint(5) unsigned NOT NULL DEFAULT '0',
  `province` smallint(5) unsigned NOT NULL DEFAULT '0',
  `city` smallint(5) unsigned NOT NULL DEFAULT '0',
  `district` smallint(5) unsigned NOT NULL DEFAULT '0',
  `address` varchar(255) NOT NULL DEFAULT '',
  `zipcode` varchar(60) NOT NULL DEFAULT '',
  `tel` varchar(60) NOT NULL DEFAULT '',
  `mobile` varchar(60) NOT NULL DEFAULT '',
  `email` varchar(60) NOT NULL DEFAULT '',
  `best_time` varchar(120) NOT NULL DEFAULT '',
  `shipping_id` tinyint(3) NOT NULL DEFAULT '0',
  `shipping_name` varchar(120) NOT NULL DEFAULT '',
  `pay_id` tinyint(3) NOT NULL DEFAULT '0',
  `pay_name` varchar(120) NOT NULL DEFAULT '',
  `how_oos` varchar(120) NOT NULL DEFAULT '',
  `goods_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pay_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `money_paid` decimal(10,2) NOT NULL DEFAULT '0.00',
  `order_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `referer` varchar(255) NOT NULL DEFAULT '',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `confirm_time` int(10) unsigned NOT NULL DEFAULT '0',
  `pay_time` int(10) unsigned NOT NULL DEFAULT '0',
  `shipping_time` int(10) unsigned NOT NULL DEFAULT '0',
  `extension_code` varchar(30) NOT NULL DEFAULT '',
  `extension_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `to_buyer` varchar(255) NOT NULL DEFAULT '',
  `pay_note` varchar(255) NOT NULL DEFAULT '',
  `agency_id` smallint(5) unsigned NOT NULL,
  `parent_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `discount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_sn` (`order_sn`),
  KEY `user_id` (`user_id`),
  KEY `order_status` (`order_status`),
  KEY `shipping_status` (`shipping_status`),
  KEY `pay_status` (`pay_status`),
  KEY `shipping_id` (`shipping_id`),
  KEY `pay_id` (`pay_id`),
  KEY `extension_code` (`extension_code`,`extension_id`),
  KEY `agency_id` (`agency_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `ws_payment`
-- -----------------------------
DROP TABLE IF EXISTS `ws_payment`;
CREATE TABLE `ws_payment` (
  `pay_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `pay_code` varchar(20) NOT NULL DEFAULT '',
  `pay_name` varchar(120) NOT NULL DEFAULT '',
  `pay_fee` varchar(10) NOT NULL DEFAULT '0',
  `pay_desc` text NOT NULL,
  `pay_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pay_config` text NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_cod` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_online` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pay_id`),
  UNIQUE KEY `pay_code` (`pay_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `ws_shipping`
-- -----------------------------
DROP TABLE IF EXISTS `ws_shipping`;
CREATE TABLE `ws_shipping` (
  `shipping_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `shipping_code` varchar(20) NOT NULL DEFAULT '',
  `shipping_name` varchar(120) NOT NULL DEFAULT '',
  `shipping_desc` varchar(255) NOT NULL DEFAULT '',
  `insure` varchar(10) NOT NULL DEFAULT '0',
  `support_cod` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `shipping_print` text NOT NULL,
  `print_bg` varchar(255) DEFAULT NULL,
  `config_lable` text,
  `print_model` tinyint(1) DEFAULT '0',
  `shipping_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`shipping_id`),
  KEY `shipping_code` (`shipping_code`,`enabled`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `ws_user`
-- -----------------------------
DROP TABLE IF EXISTS `ws_user`;
CREATE TABLE `ws_user` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(60) NOT NULL DEFAULT '',
  `username` varchar(60) NOT NULL,
  `password` varchar(32) NOT NULL DEFAULT '',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `user_money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `frozen_money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `rank_points` int(10) unsigned NOT NULL DEFAULT '0',
  `address_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_ip` varchar(15) NOT NULL DEFAULT '',
  `is_special` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `qq` varchar(20) NOT NULL,
  `office_phone` varchar(20) NOT NULL,
  `home_phone` varchar(20) NOT NULL,
  `mobile_phone` varchar(20) NOT NULL,
  `is_validated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `passwd_question` varchar(50) DEFAULT NULL,
  `passwd_answer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name` (`username`),
  KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ws_user`
-- -----------------------------
INSERT INTO `ws_user` VALUES ('1', '1027566763@qq.com', 'zqq', '123', '0', '2013-12-03', '0.00', '0.00', '0', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '', '', '057683035821', '15068812307', '0', '', '');
INSERT INTO `ws_user` VALUES ('2', '761499639@qq.com', 'zqqsvn', '123', '0', '2013-12-12', '0.00', '0.00', '0', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '', '', '057683035821', '15068812307', '0', '', '');
INSERT INTO `ws_user` VALUES ('3', '7654321@qq.com', 'cc', '123', '0', '2013-12-12', '0.00', '0.00', '0', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '', '', '057683035821', '15068812307', '0', '', '');

-- -----------------------------
-- Table structure for `ws_user_address`
-- -----------------------------
DROP TABLE IF EXISTS `ws_user_address`;
CREATE TABLE `ws_user_address` (
  `address_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `address_name` varchar(50) NOT NULL DEFAULT '',
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `email` varchar(60) NOT NULL DEFAULT '',
  `country` smallint(5) NOT NULL DEFAULT '0',
  `province` smallint(5) NOT NULL DEFAULT '0',
  `city` smallint(5) NOT NULL DEFAULT '0',
  `district` smallint(5) NOT NULL DEFAULT '0',
  `address` varchar(120) NOT NULL DEFAULT '',
  `zipcode` varchar(60) NOT NULL DEFAULT '',
  `tel` varchar(60) NOT NULL DEFAULT '',
  `mobile` varchar(60) NOT NULL DEFAULT '',
  PRIMARY KEY (`address_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

